from django.contrib import admin
from .models import Book, Order



admin.site.register(Book)
admin.site.register(Order)